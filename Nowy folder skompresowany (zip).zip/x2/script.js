const title ="3Pi coś, zdanie odnoscn8ie zadania poprzedniego xD jesstesmy : ...";
var x=0
window.onload = function create(text,h1){

	var h = document.createElement("h1");
	var x = document.createTextNode(text);
}
setInterval(sliceText,100);

function sliceText(){
	var text = title.slice(0,x);

	document.body.innerHTML=text;
	x++;
	if(x==title.length)
	{
		x=0;
	}
}